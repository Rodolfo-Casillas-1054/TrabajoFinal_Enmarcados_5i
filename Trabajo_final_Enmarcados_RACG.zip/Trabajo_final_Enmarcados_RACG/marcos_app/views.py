from django.shortcuts import render, redirect
from .models import Marcos

# Create your views here.

def Inicio_vista(request):
    losmarcos=Marcos.objects.all()
    return render(request, 'gestionarMarcos.html', {'mismarcos' : losmarcos})

def RegistrarMarcos(request):
    id_marcos=request.POST['txtid_marcos']
    medidas=request.POST['nummedidas']
    material=request.POST['txtmaterial']
    diseno=request.POST['txtdiseno']
    precio=request.POST['numprecio']
    tiempo=request.POST['numtiempo']

    guardarmarcos=Marcos.objects.create(id_marcos=id_marcos, medidas=medidas, material=material, diseno=diseno, precio=precio, tiempo=tiempo)
    return redirect ("/")



def EditarMarcos(request):
    id_marcos=request.POST['txtid_marcos']
    medidas=request.POST['nummedidas']
    material=request.POST['txtmaterial']
    diseno=request.POST['txtdiseno']
    precio=request.POST['numprecio']
    tiempo=request.POST['numtiempo']

    marcos=Marcos.objects.get(id_marcos=id_marcos)
    marcos.medidas=medidas
    marcos.material=material
    marcos.diseno=diseno
    marcos.precio=precio
    marcos.tiempo=tiempo
    marcos.save()
    return redirect ("/")

def SeleccionarMarcos(request,id_marcos):
    marcos=Marcos.objects.get(id_marcos=id_marcos)
    return render(request,"EditarMarcos.html",{"mismarcos":marcos})

def BorrarMarcos(request,id_marcos):
    marcos=Marcos.objects.get(id_marcos=id_marcos)
    marcos.delete()
    return redirect("/")