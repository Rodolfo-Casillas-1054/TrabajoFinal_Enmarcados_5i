from django.apps import AppConfig


class MarcosAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'marcos_app'
