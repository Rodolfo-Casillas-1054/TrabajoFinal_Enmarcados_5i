from django.urls import path
from empleados_app import views

urlpatterns = [
    path('', views.Inicio_vista, name='Inicio_vista'),
    path('RegistrarEmpleados/' ,views.RegistrarEmpleados, name='RegistrarEmpleados' ),
    path("SeleccionarEmpleados/<id_empleados>",views.SeleccionarEmpleados,name="SeleccionarEmpleados"),
    path("EditarEmpleados/",views.EditarEmpleados,name="EditarEmpleados"),
    path("BorrarEmpleados/<id_empleados>",views.BorrarEmpleados,name="BorrarEmpleados")
]