from django.urls import path
from clientes_app import views

urlpatterns = [
    path('', views.Inicio_vista, name='Inicio_vista'),
    path('RegistrarCliente/' ,views.RegistrarCliente, name='RegistrarCliente' ),
    path("SeleccionarCliente/<id_cliente>",views.SeleccionarCliente,name="SeleccionarCliente"),
    path("EditarCliente/",views.EditarCliente,name="EditarCliente"),
    path("BorrarCliente/<id_cliente>",views.BorrarCliente,name="BorrarCliente")
]