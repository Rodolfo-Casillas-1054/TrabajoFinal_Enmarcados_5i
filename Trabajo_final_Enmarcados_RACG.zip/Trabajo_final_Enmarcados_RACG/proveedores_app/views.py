from django.shortcuts import render, redirect
from .models import Proveedor

# Create your views here.

def Inicio_vista(request):
    losproveedores=Proveedor.objects.all()
    return render(request, 'gestionarProveedores.html', {'misproveedores' : losproveedores})

def RegistrarProveedores(request):
    id_proveedores=request.POST['txtid_proveedores']
    nombre=request.POST['txtnombre']
    direccion=request.POST['txtdireccion']
    material=request.POST['txtmaterial']
    fecha=request.POST['txtfecha']
    precio=request.POST['numprecio']

    guardarproveedores=Proveedor.objects.create(id_proveedores=id_proveedores, nombre=nombre, direccion=direccion, material=material, fecha=fecha, precio=precio)
    return redirect ("/")



def EditarProveedores(request):
    id_proveedores=request.POST['txtid_proveedores']
    nombre=request.POST['txtnombre']
    direccion=request.POST['txtdireccion']
    material=request.POST['txtmaterial']
    fecha=request.POST['txtfecha']
    precio=request.POST['numprecio']

    proveedores=Proveedor.objects.get(id_proveedores=id_proveedores)
    proveedores.nombre=nombre
    proveedores.direccion=direccion
    proveedores.material=material
    proveedores.fecha=fecha
    proveedores.precio=precio
    proveedores.save()
    return redirect ("/")

def SeleccionarProveedores(request,id_proveedores):
    proveedores=Proveedor.objects.get(id_proveedores=id_proveedores)
    return render(request,"EditarProveedores.html",{"misproveedores":proveedores})

def BorrarProveedores(request,id_proveedores):
    proveedores=Proveedor.objects.get(id_proveedores=id_proveedores)
    proveedores.delete()
    return redirect("/")