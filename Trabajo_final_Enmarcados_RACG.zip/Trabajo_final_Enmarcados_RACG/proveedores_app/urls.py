from django.urls import path
from proveedores_app import views

urlpatterns = [
    path('', views.Inicio_vista, name='Inicio_vista'),
    path('RegistrarProveedores/' ,views.RegistrarProveedores, name='RegistrarProveedores' ),
    path("SeleccionarProveedores/<id_proveedores>",views.SeleccionarProveedores,name="SeleccionarProveedores"),
    path("EditarProveedores/",views.EditarProveedores,name="EditarProveedores"),
    path("BorrarProveedores/<id_proveedores>",views.BorrarProveedores,name="BorrarProveedores")
]